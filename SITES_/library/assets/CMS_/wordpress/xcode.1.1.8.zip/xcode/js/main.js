(function($){
	$(document).ready(function(){
		$('.menu-btn').on('click', function(e){
			$('body').toggleClass('push-right');
		});
	});
}(jQuery));
