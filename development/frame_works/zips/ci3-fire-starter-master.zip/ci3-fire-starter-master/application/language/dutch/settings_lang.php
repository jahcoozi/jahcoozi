<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Settings Language File
 */

// Titles
$lang['admin settings title']             = "Instellingen";

// Messages
$lang['admin settings msg save_success']  = "Instellingen zijn met succes opgeslagen.";

// Errors
$lang['admin settings error save_failed'] = "Er was een probleem bij het opslaan van instellingen. Probeer het opnieuw.";
