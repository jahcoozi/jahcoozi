<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Admin Dashboard Language File
 */

// Text
$lang['admin dashboard text welcome']  = "Hallo en welkom op het dashboard !";

// Buttons
$lang['admin dashboard btn demo']      = "Klik voor Jsi18n Demo";

// Jsi18n Demo
$lang['admin dashboard jsi18n-sample'] = "Dit is een demonstratie van de Jsi18n bibliotheek. Het neemt tekst uit een taalbestand en voegt het in uw Javascripts. Zie de jsi18n.php bibliotheek en dashboard_i18n.js voor gebruik.";
