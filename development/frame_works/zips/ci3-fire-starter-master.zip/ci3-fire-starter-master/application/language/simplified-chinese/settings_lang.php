<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Settings Language File
 * author Evenvi
 * www.evenvi.com
 */

// Titles
$lang['admin settings title']             = "设置";

// Messages
$lang['admin settings msg save_success']  = "设置保存成功.";

// Errors
$lang['admin settings error save_failed'] = "设备保存失败!请重试.";
