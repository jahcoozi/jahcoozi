<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Admin Dashboard Language File
 */

// Text
$lang['admin dashboard text welcome']  = "¡Hola y bienvenidos al tablero!";

// Buttons
$lang['admin dashboard btn demo']      = "Haga clic para Jsi18n demo";

// Jsi18n Demo
$lang['admin dashboard jsi18n-sample'] = "Esta es una demostración de la biblioteca jsi18n. Se necesita texto de un archivo de idioma y lo inserta en su Javascripts. Ver la biblioteca jsi18n.php y dashboard_i18n.js para su uso.";
