<?php	defined('BASEPATH') OR exit('Akses skrip secara langsung tidak diijinkan');
/**
 * File Bahasa Indoensia - Settings
 */

// Titles
$lang['admin settings title']             = "Pengaturan";

// Messages
$lang['admin settings msg save_success']  = "Pengaturan telah berhasil disimpan.";

// Errors
$lang['admin settings error save_failed'] = "Terdapat masalah dalam menyimpan pengaturan. Silakan coba lagi.";
