Bromine Font

The Bromine font is a handwriting Unicode font created in iFontMaker and refined in FontLab Studio. This is my first attempt at a font with Unicode characters. It comes with alphanumeric characters, punctuation and international characters. There are no Greek and Cyrillic characters. Like all other fonts, this font is in the public domain.

Please read the terms of use at http://jlhfonts.blogspot.com/.